﻿using System;

class Program
{
    static void Main()
    {
        int[] intArray = { 1, 2, 3, 4, 5 };
        float intAverage = AverageMethods.Average(intArray);
        Console.WriteLine($"Среднее арифметическое для массива int: {intAverage}");

        float[] floatArray = { 1.5f, 2.5f, 3.5f, 4.5f };
        float floatAverage = AverageMethods.Average(floatArray);
        Console.WriteLine($"Среднее арифметическое для массива float: {floatAverage}");
    }
}

class AverageMethods
{
    public static float Average(int[] numbers)
    {
        if (numbers.Length == 0) return 0;
        float sum = 0;
        foreach (int number in numbers)
        {
            sum += number;
        }
        return sum / numbers.Length;
    }

    public static float Average(float[] numbers)
    {
        if (numbers.Length == 0) return 0;
        float sum = 0;
        foreach (float number in numbers)
        {
            sum += number;
        }
        return sum / numbers.Length;
    }
}
