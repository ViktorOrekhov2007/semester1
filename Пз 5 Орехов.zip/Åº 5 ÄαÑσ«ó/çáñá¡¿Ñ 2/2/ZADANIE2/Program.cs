﻿using System;

class MainClass
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Введите значение стороны a:");
        double a = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("Введите значение стороны b:");
        double b = Convert.ToDouble(Console.ReadLine());

        double c = Math.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2));

        Console.WriteLine("Значение стороны c по теореме Пифагора: " + c);
    }
}
