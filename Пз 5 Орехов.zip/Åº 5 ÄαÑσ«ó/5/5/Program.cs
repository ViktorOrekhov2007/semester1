﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Заданные значения x и y
        double x = 2;
        double y = 5;

        // Решение уравнения
        double numerator = x - y;
        double denominator = 1 + x * y;
        double result = numerator / denominator;

        // Вывод результата
        Console.WriteLine("Решение уравнения:");
        Console.WriteLine($"({x} - {y}) / (1 + {x} * {y}) = {result}");
    }
}
