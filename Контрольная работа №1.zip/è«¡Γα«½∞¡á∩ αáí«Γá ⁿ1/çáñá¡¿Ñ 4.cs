﻿using System;
using System.Collections.Generic;

class Program4
{
    static void Main4()
    {
        int n = int.Parse(Console.ReadLine());
        Dictionary<char, int> agentWordCount = new Dictionary<char, int>();
        for (int i = 0; i < n; i++)
        {
            string input = Console.ReadLine();
            char agentId = input[0];
            if (agentWordCount.ContainsKey(agentId))
            {
                agentWordCount[agentId]++;
            }
            else
            {
                agentWordCount[agentId] = 1;
            }
        }
        int maxWords = 0;
        foreach (var count in agentWordCount.Values)
        {
            if (count > maxWords)
            {
                maxWords = count;
            }
        }
        Console.WriteLine(maxWords);
    }
}