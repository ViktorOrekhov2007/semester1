﻿using System;

class Program5
{
    static void Main5()
    {
        string[] input = Console.ReadLine().Split();
        int N = int.Parse(input[0]);
        double threshold = double.Parse(input[1]);

        double[] temperatures = new double[N];
        for (int i = 0; i < N; i++)
        {
            temperatures[i] = double.Parse(Console.ReadLine());
        }
        double minTemperature = double.MaxValue;
        int minDay = -1;
        int aboveThresholdCount = 0;

        for (int i = 0; i < N; i++)
        {
            if (temperatures[i] < minTemperature)
            {
                minTemperature = temperatures[i];
                minDay = i + 1;
            }
            if (temperatures[i] > threshold)
            {
                aboveThresholdCount++;
            }
        }
        Console.WriteLine(minDay);
        Console.WriteLine(aboveThresholdCount);
    }
}