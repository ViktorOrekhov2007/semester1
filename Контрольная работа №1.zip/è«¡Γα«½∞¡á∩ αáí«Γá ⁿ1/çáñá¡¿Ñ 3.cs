﻿using System;

class Program3
{
    static void Main3()
    {
        string[] input = Console.ReadLine().Split();
        int n = int.Parse(input[0]);
        int validCount = 0;
        for (int i = 1; i <= n; i++)
        {
            int number = int.Parse(input[i]);
            if (number >= 100000 && number < 1000000 && number % 8 == 0)
            {
                validCount++;
            }
        }
        Console.WriteLine(validCount);
    }
}