﻿using System;
using System.Collections.Generic;
public struct Rectangle
{
    public double X1 { get; set; }
    public double Y1 { get; set; }
    public double X2 { get; set; }
    public double Y2 { get; set; }
    public Rectangle(double x1, double y1, double x2, double y2)
    {
        X1 = x1;
        Y1 = y1;
        X2 = x2;
        Y2 = y2;
    }
    public double Width => X2 - X1;
    public double Height => Y2 - Y1;
}
class Program
{
    static void Main(string[] args)
    {
        List<Rectangle> rectangles = new List<Rectangle>();
        Console.WriteLine("Введите количество прямоугольников (до 10):");
        int count;
        while (true)
        {
            string input = Console.ReadLine();
            if (int.TryParse(input, out count) && count > 0 && count <= 10)
            {
                break; 
            }
            else
            {
                Console.WriteLine("Пожалуйста, введите число от 1 до 10.");
            }
        }
        for (int i = 0; i < count; i++)
        {
            Console.WriteLine($"Прямоугольник {i + 1}:");
            Console.Write("Введите x1, y1, x2, y2 (через пробел): ");
            string rectInput = Console.ReadLine();

            while (true)
            {
                if (string.IsNullOrWhiteSpace(rectInput))
                {
                    Console.WriteLine("Введите координаты прямоугольника.");
                    rectInput = Console.ReadLine();
                    continue;
                }
                string[] parts = rectInput.Split(' ');
                if (parts.Length != 4 ||
                    !double.TryParse(parts[0], out double x1) ||
                    !double.TryParse(parts[1], out double y1) ||
                    !double.TryParse(parts[2], out double x2) ||
                    !double.TryParse(parts[3], out double y2))
                {
                    Console.WriteLine("Неверный ввод. Пожалуйста, введите 4 числа через пробел.");
                    rectInput = Console.ReadLine(); 
                    continue;
                }
                rectangles.Add(new Rectangle(x1, y1, x2, y2));
                break; 
            }
        }
        if (rectangles.Count > 0)
        {
            Rectangle boundingRect = GetBoundingRectangle(rectangles);
            Console.WriteLine($"Минимальный охватывающий прямоугольник: ({boundingRect.X1}, {boundingRect.Y1}), ({boundingRect.X2}, {boundingRect.Y2})");
            Console.Write("Введите координаты точки (x, y) для проверки: ");
            string pointInput = Console.ReadLine();
            string[] pointParts = pointInput.Split(' ');
            if (pointParts.Length == 2 &&
                double.TryParse(pointParts[0], out double pointX) &&
                double.TryParse(pointParts[1], out double pointY))
            {
                List<Rectangle> containingRects = FindContainingRectangles(rectangles, pointX, pointY);

                Console.WriteLine($"Прямоугольники, охватывающие точку ({pointX}, {pointY}):");
                foreach (var rect in containingRects)
                {
                    Console.WriteLine($"({rect.X1}, {rect.Y1}), ({rect.X2}, {rect.Y2})");
                }
            }
            else
            {
                Console.WriteLine("Неверный ввод координат точки.");
            }
        }
        else
        {
            Console.WriteLine("Не было введено ни одного прямоугольника.");
        }
    }
    public static Rectangle GetBoundingRectangle(List<Rectangle> rectangles)
    {
        if (rectangles == null || rectangles.Count == 0)
            throw new ArgumentException("Список прямоугольников не может быть пустым.");
        double minX = rectangles[0].X1;
        double minY = rectangles[0].Y1;
        double maxX = rectangles[0].X2;
        double maxY = rectangles[0].Y2;
        foreach (var rect in rectangles)
        {
            minX = Math.Min(minX, rect.X1);
            minY = Math.Min(minY, rect.Y1);
            maxX = Math.Max(maxX, rect.X2);
            maxY = Math.Max(maxY, rect.Y2);
        }
        return new Rectangle(minX, minY, maxX, maxY);
    }
    public static bool ContainsPoint(Rectangle rect, double x, double y)
    {
        return x >= rect.X1 && x <= rect.X2 && y >= rect.Y1 && y <= rect.Y2;
    }
    public static List<Rectangle> FindContainingRectangles(List<Rectangle> rectangles, double x, double y)
    {
        List<Rectangle> containingRectangles = new List<Rectangle>();
        foreach (var rect in rectangles)
        {
            if (ContainsPoint(rect, x, y))
            {
                containingRectangles.Add(rect);
            }
        }
        return containingRectangles;
    }
}
