﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace PointSorting
{
    class Point
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
        public double DistanceFromOrigin()
        {
            return Math.Sqrt(X * X + Y * Y + Z * Z);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Point> points = new List<Point>();
            Console.Write("Введите количество точек: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Введите координаты точки {i + 1} (x y z): ");
                string[] coordinates = Console.ReadLine().Split(' ');
                Point point = new Point
                {
                    X = double.Parse(coordinates[0]),
                    Y = double.Parse(coordinates[1]),
                    Z = double.Parse(coordinates[2])
                };
                points.Add(point);
            }
            var sortedPoints = points.OrderBy(p => p.DistanceFromOrigin()).ToList();
            double minDistance = sortedPoints.First().DistanceFromOrigin();
            double maxDistance = sortedPoints.Last().DistanceFromOrigin();
            Console.WriteLine("\nОтсортированные точки по удалению от начала координат:");
            foreach (var point in sortedPoints)
            {
                Console.WriteLine($"Точка: ({point.X}, {point.Y}, {point.Z}), Расстояние: {point.DistanceFromOrigin()}");
            }
            Console.WriteLine($"\nМинимальное расстояние: {minDistance}");
            Console.WriteLine($"Максимальное расстояние: {maxDistance}");
            Console.ReadKey();
        }
    }
}
