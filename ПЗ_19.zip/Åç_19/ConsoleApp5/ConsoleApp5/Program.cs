﻿using System;
using System.Linq;
namespace ComplexNumbers
{
    public class Complex
    {
        public double Real { get; }
        public double Imaginary { get; }
        public Complex(double real, double imaginary)
        {
            Real = real;
            Imaginary = imaginary;
        }
        public double Modulus()
        {
            return Math.Sqrt(Real * Real + Imaginary * Imaginary);
        }
        public override string ToString()
        {
            return $"{Real} + {Imaginary}i";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество комплексных чисел:");
            int count = int.Parse(Console.ReadLine());
            Complex[] numbers = new Complex[count];
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"Введите реальную и мнимую часть для комплексного числа {i + 1} (например, 3 4 для 3 + 4i):");
                var input = Console.ReadLine().Split(' ');
                double real = double.Parse(input[0]);
                double imaginary = double.Parse(input[1]);
                numbers[i] = new Complex(real, imaginary);
            }
            var sortedNumbers = numbers.OrderBy(n => n.Modulus()).ToArray();
            Console.WriteLine("\nКомплексные числа, отсортированные по модулю:");
            foreach (var number in sortedNumbers)
            {
                Console.WriteLine(number);
            }
            Console.WriteLine("\nКомплексные числа по квадрантам:");
            foreach (var number in numbers)
            {
                string quadrant = GetQuadrant(number);
                Console.WriteLine($"{number} находится в {quadrant} квадранте.");
            }
            Complex product = MultiplyComplexNumbers(numbers);
            Console.WriteLine($"\nПроизведение всех комплексных чисел: {product}");
        }
        static string GetQuadrant(Complex number)
        {
            if (number.Real > 0 && number.Imaginary > 0) return "I";
            if (number.Real < 0 && number.Imaginary > 0) return "II";
            if (number.Real < 0 && number.Imaginary < 0) return "III";
            if (number.Real > 0 && number.Imaginary < 0) return "IV";
            return "На оси";
        }
        static Complex MultiplyComplexNumbers(Complex[] numbers)
        {
            double realPart = 1;
            double imaginaryPart = 0;
            foreach (var number in numbers)
            {
                double tempReal = realPart * number.Real - imaginaryPart * number.Imaginary;
                imaginaryPart = realPart * number.Imaginary + imaginaryPart * number.Real;
                realPart = tempReal;
            }
            return new Complex(realPart, imaginaryPart);
        }
    }
}
