﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filePath = @"C:\Users\Student28\Desktop\Новая папка\WindowsFormsApp1\WindowsFormsApp1\bin\Страхователи.txt";
            using (StreamWriter sw = File.AppendText (filePath))
            try
            {
                {
                        sw.WriteLine($"Фамилия " + textBox1.Text);
                        sw.WriteLine($"Имя " + textBox2.Text);
                        sw.WriteLine($"Город " + textBox3.Text);
                        sw.WriteLine($"Улица " + textBox4.Text);
                        sw.WriteLine($"Дом " + textBox5.Text);
                        sw.WriteLine($"Кв " + textBox6.Text);
                        sw.WriteLine($"Пол:" + textBox1.Text);
                        sw.WriteLine($"Срок страхования:" + numericUpDown1.Value.ToString());
                        sw.WriteLine($"Вид страхования:" + comboBox1.SelectedItem.ToString());
                    }
                    
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
            MessageBox.Show("Данное успешно сохранены в файлы!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
